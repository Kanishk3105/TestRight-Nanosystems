# Device Log Summarizer

A small Python command-line tool for validating device telemetry CSV records, summarizing valid readings by device, exporting a JSON report, and charting retained average temperatures.

## Features

- Uses Python's standard `csv`, `json`, and `argparse` modules for processing.
- Reports per-device valid record totals, arithmetic mean temperatures, and ERROR counts.
- Retains devices with average temperature less than or equal to **80.0 °C**.
- Rejects malformed records instead of inventing values.
- Writes JSON atomically and reports actionable errors to stderr.
- Creates a labeled Matplotlib chart from a validated JSON report.
- Leaves the assessment's Section 1 implementation for the candidate to complete independently.

## Prerequisites and installation

- Python 3.10 or newer.
- pip.

In Windows PowerShell, from this directory:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell's execution policy prevents activation, run the environment's Python directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The only external dependency is Matplotlib. Python's `unittest` is included in the standard library.

## Project structure

```text
main.py                          CSV processing CLI (Section 2)
plot_results.py                  JSON-to-PNG chart CLI (Section 3)
sanitize.py                      Intentionally unimplemented Section 1 placeholder
requirements.txt                 Matplotlib dependency
summary.json                     Illustrative report generated from the synthetic fixture
temperature_chart.png            Chart generated from that illustrative report
tests/
  test_main.py                   Section 2 tests
  test_plot_results.py           Section 3 tests
  fixtures/
    sample_device_telemetry.csv  Synthetic test data; not official assessment data
```

## CSV schema and data policy

The CSV header must include `device_id`, `status`, and `temperature`. Additional columns are ignored. For example (illustrative only):

```csv
device_id,status,temperature
DEVICE_1,OK,42.5
DEVICE_1,ERROR,45
```

Whitespace around header and field text is stripped. A data row is rejected in full if its device ID, status, or temperature is blank; if the row has missing/extra fields; or if temperature cannot be parsed as a finite number. CSV syntax errors, absent files, absent headers, and missing required columns are fatal errors and do not produce a report. Invalid temperatures are never replaced with zero.

`total_input_rows` counts data records read from the CSV, including rejected records. `valid_rows` and each device's `total_records` count only rows with nonblank device ID/status and a finite numeric temperature. `rejected_rows` counts rows excluded by row validation. `error_count` counts valid records whose status equals `ERROR` without regard to case. `excluded_devices` counts devices with valid rows whose mean exceeds the threshold. Devices with no valid rows are not included in aggregation.

The mean is the arithmetic mean of valid readings. A mean of exactly **80.0 °C is retained**; only a mean strictly greater than 80.0 °C is excluded. Device entries are ordered lexicographically by device ID for reproducibility.

## Run the processor

Defaults point to `device_telemetry.csv` and `summary.json` beside `main.py`, regardless of the current working directory. The official `device_telemetry.csv` was not present when this project was prepared; do not treat the synthetic fixture as a replacement.

After obtaining the official CSV, place it at the project root, then run:

```powershell
python .\main.py
```

Or specify paths explicitly:

```powershell
python .\main.py --input "C:\path\to\device_telemetry.csv" --output ".\summary.json"
```

The equivalent from another current directory is:

```powershell
python "C:\TestRight Nanosystems\main.py" --input "C:\path\to\device_telemetry.csv" --output "C:\path\to\summary.json"
```

An illustrative run with the synthetic test fixture is:

```powershell
python .\main.py --input .\tests\fixtures\sample_device_telemetry.csv --output .\summary.json
```

The output reports a concise table and row/device counts. On fatal input or output errors, the command reports an error to stderr and returns a nonzero status; it does not print a success message.

## Generate the chart

With a generated `summary.json`, run:

```powershell
python .\plot_results.py
```

Specify paths if needed:

```powershell
python .\plot_results.py --input .\summary.json --output .\temperature_chart.png
```

The chart labels both axes, has the title **Average Temperature by Device**, rotates device labels, and adjusts its layout for longer lists. An empty device list or invalid JSON/device entry is an error, not a successful empty chart.

## Run tests

Run only the Section 2 and 3 test suites:

```powershell
python -m unittest discover -s tests -v
```

The tests use temporary files and a clearly marked synthetic CSV fixture; they do not overwrite the official input. On macOS/Linux, use the equivalent `python3 -m unittest discover -s tests -v`.

## Outputs

- `summary.json`: report containing the source path, filter, retained device summaries, and input/valid/rejected/excluded counts.
- `temperature_chart.png`: PNG bar chart of retained device averages.

The checked-in/prepared sample outputs, when present, are illustrative and were generated from `tests/fixtures/sample_device_telemetry.csv`, which is synthetic. The original recruiter-provided CSV was unavailable, so no official-data result is included or claimed.

## Limitations and error handling

- No official CSV was available in the workspace during preparation; official-data validation remains outstanding.
- The chart shows retained averages only. Excluded devices are not plotted.
- CSV rows that cannot be assigned the required fields are rejected; malformed CSV syntax is fatal because record boundaries may no longer be reliable.
- The program does not modify or create the official input CSV.
- The candidate must independently implement Section 1 in `sanitize.py`; it is intentionally not tested or imported by the other sections.

## Submission checklist

- [ ] Add the recruiter-provided `device_telemetry.csv` (do not substitute the test fixture).
- [ ] Run the processor against the official CSV and review `summary.json`.
- [ ] Generate and inspect `temperature_chart.png`.
- [ ] Independently complete Section 1 in `sanitize.py`.
- [ ] Run the Section 2/3 test suite.
- [ ] Include source, tests, README, prompt log, requirements, and expected outputs.
- [ ] Replace this illustrative report/chart with official-data outputs before claiming official validation.
