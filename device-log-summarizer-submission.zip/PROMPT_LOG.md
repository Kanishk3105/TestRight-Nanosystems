# AI Prompt Log

## Initial Prompt

**Extract from the assessment PDF, Section 3, item 1:**

> Ask an AI assistant to write a Python script that loads your JSON output from Section 2 and generates a bar chart comparing the average temperature per device using matplotlib.

The assessment also requires reviewing the first output, fixing any actual layout or formatting bug, and documenting the initial prompt, observed issue, and follow-up prompt.

## First Attempt Review

For the isolated first attempt, I used six synthetic device IDs, each 158 characters long. Running `python .\review-only\chart-first-attempt\first_attempt_plot.py` created `review-only\chart-first-attempt\first_attempt_chart.png` and Matplotlib warned: `Tight layout not applied. The bottom and top margins cannot be made large enough to accommodate all Axes decorations.` I inspected the actual PNG: the device labels were clipped at the bottom, and the x-axis label was not visible.

## Follow-up Prompt

**Verbatim correction instructions from the follow-up request:**

> TASK 1 — FIX THE CHART
>
> 1. Inspect review-only/chart-first-attempt/first_attempt_plot.py and the associated synthetic test JSON and PNG.
> 2. Inspect the existing production plot_results.py before editing it.
> 3. Fix the chart layout so long device IDs remain readable and are not clipped. Choose an appropriate solution such as wrapped labels, a suitably sized figure, a horizontal bar chart, or a combination of these techniques.
> 4. Ensure the chart has the title "Average Temperature by Device", a readable device label axis, and the axis label "Average Temperature (°C)" for temperature values.
> 5. Ensure the layout does not produce the previous tight_layout warning.
> 6. Do not hardcode the six test devices or their values into production code.
> 7. Preserve the real JSON-driven chart functionality.
> 8. Add or update regression tests for long device IDs.
> 9. Regenerate the separate review chart and inspect the actual PNG to verify that the original clipping issue is fixed.
> 10. If image inspection is not available, report this limitation honestly.

## Correction

The production chart implementation already present at the start of this follow-up wraps long device IDs at 18 characters, keeps tick labels horizontal, and grows the figure height according to the number of wrapped label lines. It continues to load and plot device data from the supplied JSON; it does not hardcode the synthetic devices. The existing long-ID regression test checks for the previous tight-layout warning and a non-collapsed output image. No change to `plot_results.py` was needed in this follow-up; I regenerated a separate review chart using the production script and the supplied synthetic JSON.

## Verification

- Ran `python .\review-only\chart-first-attempt\first_attempt_plot.py`; it produced a 1500 × 900 PNG and the warning/clipping described above.
- Ran `python .\plot_results.py --input .\review-only\chart-first-attempt\synthetic_device_summary.json --output .\review-only\chart-first-attempt\corrected_production_chart.png`; it produced a valid 1319 × 1093 PNG (58,644 bytes), which was opened and visually inspected. All six long IDs are wrapped and readable, the `Device ID` x-axis label is visible, the title is present, and the temperature axis reads `Average Temperature (°C)`. The prior tight-layout warning did not occur.
- Ran `python -m unittest discover -s tests -v`: 23 tests passed, 0 failed.
- Ran `python -m py_compile main.py sanitize.py plot_results.py tests\__init__.py tests\test_main.py tests\test_plot_results.py review-only\chart-first-attempt\first_attempt_plot.py`: succeeded.
- Ran Section 2 with `python .\main.py --input .\tests\fixtures\sample_device_telemetry.csv --output C:\Users\kanis\AppData\Local\Temp\section2-check-d1755f38555f4e21ad823b05c5f02f30\summary.json`; assertions confirmed DEV_A's 45.0 °C and DEV_B's exactly 80.0 °C averages, with the latter retained. This fixture is synthetic, not the official assessment CSV.

## AI Usage Summary

AI assistance was used for Section 2, the Section 3 chart implementation and review, regression testing, and documentation. `sanitize.py` remains a placeholder. No Section 1 implementation or tests were generated; Section 1 remains the candidate's independent work.
